META ADS - app package
Option A (APK): upload everything to a new GitHub repo. Actions builds MetaAds.apk -> Releases -> latest.
Option B (installable web app): repo Settings > Pages > Deploy from branch > /docs. Open the link in Chrome > menu > Install app.
